import React from 'react';

function HomeAdmin() {
  return (
    
          
   <div style={{backgroundColor:"lavender",height:"120%"}}>
          <div class="position-relative overflow-hidden p-1 p-md-5 m-md-3 text-center" style={{height:"100%"}}>
  <div class="col-md-5 p-lg-5 mx-auto my-5">
    <h1 class="display-4 font-weight-normal">Welcome To Admin..!</h1>
    <p class="lead font-weight-normal">Professional And Developer Friendly Admin Dashboard.</p><br></br>
    <a class="btn btn-outline-danger" target="_blank" href="https://www.cdac.in/">Our Institute</a>
  </div>
  <div class="product-device shadow-sm d-none d-md-block"></div>
  <div class="product-device product-device-2 shadow-sm d-none d-md-block"></div>
</div>

</div>



  );
}

export default HomeAdmin;
