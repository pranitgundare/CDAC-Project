import react from 'react';
import './Contact.css';
import Shubham1 from '../photo/Shubham1.jpg';
import Aparna1 from '../photo/Aparna1.jpg';
import Pranit1 from '../photo/Pranit1.jpg';
import Ajinkya1 from '../photo/Ajinkya1.jpg';
import Swapnil1 from '../photo/Swapnil1.jpg';
import Nitin1 from '../photo/Nitin1.jpg';
const Contact = props => {
  return (
    <>
      <div >
      <br></br>
        <h1 style={{fontWeight:"bold"}}>Contact Us</h1><br />
        
     
        <div className="container-fluid d-flex justify-content-center">
          <div className="row" >

            <div className="card text-center mb-2 mr-2 class="border-dark >
              <div className="overflow">
                <img src={Aparna1} alt="" className="card-img-top" />
              </div>
              <div className="card-body text-dark">
                <h4 className="card-title">Aparna Thakre</h4>
                <p className="card-text text-secondary">
                  <dd>aparnathakre17@gmail.com</dd>
                  <dd></dd>
                </p>
              </div>
            </div>

            <div className="card text-center mb-2 mr-2">
              <div className="overflow">
                <img src={Pranit1} alt="" className="card-img-top" />
              </div>
              <div className="card-body text-dark">
                <h4 className="card-title">Pranit Gundare</h4>
                <p className="card-text text-secondary">
                  <dd>pranitgundare@gmail.com</dd>
                  <dd></dd>
                </p>
              </div>
            </div>

            <div className="card text-center mb-2 mr-2">
              <div className="overflow">
                <img src={Swapnil1} alt="" className="card-img-top" />
              </div>
              <div className="card-body text-dark">
                <h4 className="card-title">Swapnil Andhale</h4>
                <p className="card-text text-secondary">
                  <dd>swapnil11197@gmail.com</dd>
                  <dd></dd>
                </p>
              </div>
            </div>

          </div>
        </div>

        <div className="container-fluid d-flex justify-content-center">
          <div className="row  mt-3">

            <div className="card text-center mr-2">
              <div className="overflow">
                <img src={Shubham1} alt="" className="card-img-top" />
              </div>
              <div className="card-body text-dark">
                <h4 className="card-title">Shubham Sawake</h4>
                <p className="card-text text-secondary">
                  <dd>shubhamsawake28@gmail.com</dd>
                  <dd></dd>
                </p>
              </div>
            </div>

            <div className="card text-center mr-2">
              <div className="overflow">
                <img src={Nitin1} alt="" className="card-img-top" />
              </div>
              <div className="card-body text-dark">
                <h4 className="card-title">Nitin Gaikwad</h4>
                <p className="card-text text-secondary">
                  <dd>nitinns.gaikwad@gmail.com</dd>
                  <dd></dd>
                </p>
              </div>
            </div>

            <div className="card text-center">
              <div className="overflow">
                <img src={Ajinkya1} alt="" className="card-img-top" />
              </div>
              <div className="card-body text-dark">
                <h4 className="card-title">Ajinkya Surashe</h4>
                <p className="card-text text-secondary">
                  <dd>Surasheajinkya1995@gmail.com</dd>
                  <dd></dd>
                </p>
              </div>
            </div>

          </div>
        </div>
        <br></br>
        <br></br>
        <br></br>
      </div>
    </>
  );
}

export default Contact;